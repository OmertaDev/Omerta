import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';
import {createHash} from 'node:crypto';
import {keccak256,toHex} from 'viem';
const base=path.resolve('omerta-contracts'),out=path.resolve('output/pr310-native-eth-2026-11-04/slither-standard-json');
const solc='C:/Users/Jorge/.solc-select/artifacts/solc-0.8.38/solc-0.8.38';
const sha=x=>createHash('sha256').update(x).digest('hex');
const targets=['OmertaEthStakingV2','OmertaEthRewardsV2'];
const sourcePins={},sources={},artifacts={};let settings;
for(const name of targets){
  const bytes=fs.readFileSync(path.join(base,'out',name+'.sol',name+'.json')),a=JSON.parse(bytes),m=typeof a.rawMetadata==='string'?JSON.parse(a.rawMetadata):a.metadata;
  if(m.compiler.version!=='0.8.38+commit.1835d247'||m.settings.optimizer.runs!==800||!m.settings.optimizer.enabled||!m.settings.viaIR||m.settings.evmVersion!=='cancun')throw Error('wrong compiler/settings');
  const candidate=structuredClone(m.settings);delete candidate.compilationTarget;
  if(settings&&JSON.stringify(settings)!==JSON.stringify(candidate))throw Error('target settings differ');settings=candidate;
  artifacts[name]={sha256:sha(bytes),source:'src/market-v2/'+name+'.sol',creation:a.bytecode.object,runtime:a.deployedBytecode.object};
  for(const[file,pin]of Object.entries(m.sources)){
    const raw=fs.readFileSync(path.join(base,file)),lf=raw.toString('utf8').replace(/\r\n/g,'\n');
    const content=keccak256(toHex(lf))===pin.keccak256?lf:keccak256(toHex(raw))===pin.keccak256?raw.toString('utf8'):null;
    if(content===null)throw Error('stale artifact source '+file);
    if(sources[file]&&sources[file].content!==content)throw Error('conflicting source '+file);
    sources[file]={content};sourcePins[file]={sha256Raw:sha(raw),sha256CompilerInput:sha(content),keccak256:pin.keccak256};
  }
}
settings.outputSelection={'*':{'*':['abi','metadata','devdoc','userdoc','evm.bytecode','evm.deployedBytecode'],'':['ast']}};
const input={language:'Solidity',sources:Object.fromEntries(Object.entries(sources).sort()),settings};
const inputBytes=JSON.stringify(input,null,2)+'\n';fs.writeFileSync(path.join(out,'input.json'),inputBytes);
const version=cp.spawnSync(solc,['--version'],{encoding:'utf8',windowsHide:true});if(version.status!==0)throw Error('compiler unavailable');
fs.writeFileSync(path.join(out,'solc-version.txt'),version.stdout+version.stderr);
const argv=['--standard-json'],started=new Date().toISOString(),run=cp.spawnSync(solc,argv,{input:inputBytes,encoding:'utf8',windowsHide:true,maxBuffer:150*1024*1024});
fs.writeFileSync(path.join(out,'solc-output.json'),run.stdout||'');fs.writeFileSync(path.join(out,'solc-stderr.log'),run.stderr||'');
if(run.error)throw run.error;const result=JSON.parse(run.stdout);const errors=(result.errors||[]).filter(x=>x.severity==='error');
const matches={};for(const name of targets){const a=artifacts[name],c=result.contracts?.[a.source]?.[name];matches[name]={artifactSha256:a.sha256,creationMatch:'0x'+c?.evm?.bytecode?.object===a.creation,runtimeMatch:'0x'+c?.evm?.deployedBytecode?.object===a.runtime,creationBytes:(a.creation.length-2)/2,runtimeBytes:(a.runtime.length-2)/2};}
const summary={started,finished:new Date().toISOString(),baseRevision:cp.spawnSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).stdout.trim(),dirtyWorkingTree:true,scope:targets,sourceCount:Object.keys(sources).length,sourcePins,compiler:{path:solc,sha256:sha(fs.readFileSync(solc)),version:version.stdout.trim(),argv,settings},inputSha256:sha(inputBytes),outputSha256:sha(run.stdout),stderrSha256:sha(run.stderr||''),exit:run.status,compilerDiagnostics:result.errors||[],artifactComparison:matches,productionWrites:false,forgeInvoked:false};
fs.writeFileSync(path.join(out,'COMPILATION.json'),JSON.stringify(summary,null,2)+'\n');
if(run.status!==0||errors.length||Object.values(matches).some(x=>!x.creationMatch||!x.runtimeMatch))throw Error('compile or exact artifact comparison failed');
console.log(JSON.stringify({status:'PASS',sources:summary.sourceCount,artifactComparison:matches,compilerWarnings:(result.errors||[]).length,forgeInvoked:false}));
